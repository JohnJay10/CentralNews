

<?php $__env->startSection('content'); ?>




    <div class="content-wrapper">
      <div class="card">
<div class="card-body">
    <div class="d-flex justify-content-between">
        <a href="/post/create"> 
            <input type="submit" value="Create post " class="btn btn-primary ">
        </a>
        <a href="/post/trash"> 
            <input type="submit" value=" trash " class="btn btn-danger ">
        </a>

    </div>
   
     <br><br>
<h2 class="card-title">All posts</h2>

<div class="row">
  <div class="col-12">
    <div class="table-responsive">
        <table id="order-listing" class="table">
          <?php if(count($posts)>0): ?>
          <thead>
            <tr>
           
              <th>title </th>
              <th>slug </th>
              <th>EDIT FUNCTION</th>
              <th>DELETE FUNCTION</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              
              <td><?php echo e($post->title); ?></td>
              <td><?php echo e($post->slug); ?></td>
              

              <td>

               
                <a href="/post/<?php echo e($post->id); ?>/edit"> 
                  <input type="submit" value="edit" class="btn btn-primary ">
                </a> 
              
              </td>
              <td>

                <form action="/post/<?php echo e($post->id); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                 <?php echo e(method_field('DELETE')); ?>

                
                 <input type="submit" name ="submit" value ="delete" class="btn btn-danger">
              </form>
              </td>
             
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
          </tbody>
          <?php else: ?>


          <p>You Have no post</p>
          
          <?php endif; ?>
        </table>
         
        
      </div>
    </div>
</div>
</div>

    </div>
    
   
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\KogiNewsBlog\resources\views/post/index.blade.php ENDPATH**/ ?>