

<?php $__env->startSection('content'); ?>
<div class="col-12 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        
        <h2 class="card-description" style="font: 500;">
         CREATE LATEST NEWS POST
        </h2>
        <form class="forms-sample" method="POST" action="<?php echo e(route('latestnews.store')); ?>" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

          <div class="form-group">
            <label for="exampleInputName1">Title</label>
            <input type="text" class="form-control" id="exampleInputName1" placeholder="Title of your post" name="title" required>
          </div>
        
          <div class="form-group">
            <label>File upload</label>
            <input type="file" name="image" class="file-upload-default">
            <div class="input-group col-xs-12">
              <input type="text" class="form-control file-upload-info" disabled placeholder="Upload Image">
              <span class="input-group-append">
                <button class="file-upload-browse btn btn-primary" type="button">Upload</button>
              </span>
            </div>
          </div>
          <div class="form-group">
            <label for="exampleTextarea1">preview</label>
            <textarea class="  form-control" name="preview" id="exampleTextarea1" rows="4" required></textarea>
          </div>
          <div class="form-group">
            <label for="exampleTextarea1">Textarea</label>
            <textarea class="  form-control" name="body" id="exampleTextarea1" rows="4" required></textarea>
          </div>
          <button type="submit" class="btn btn-primary mr-2">Submit</button>
          <button class="btn btn-light">Cancel</button>
        </form>
      </div>
    </div>
  </div> 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\KogiNewsBlog\resources\views/latestnews/create.blade.php ENDPATH**/ ?>