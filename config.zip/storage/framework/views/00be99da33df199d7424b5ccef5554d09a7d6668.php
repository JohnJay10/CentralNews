

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
    <div class="container">
      <div class="col-sm-12">
        <div class="card" data-aos="fade-up">
          <div class="card-body">
            <div class="row">
             
              <div class="col-sm-12">
                <h1 class="font-weight-600 mb-4">
                  <?php echo e($post->title); ?>

                </h1>
              </div>
            </div>
           
            <div class="row">
              <div class="col-lg-12">
                <div class="row">
                  <div class="col-sm-12 grid-margin">
                    <img style="width: 70%"
                    src="<?php echo e($post->url); ?>"
                    alt="banner"
                    class="img-fluid"
                  />
                  </div>
                  <div class="col-sm-12 grid-margin">
                 
                    <p class="fs-13 text-muted mb-0" ">
                      <span class="mr-2" >Posted </span><?php echo e($post->created_at->diffForHumans()); ?>

                    </p>
                    <p class="fs-15">
                      <?php echo $post->body; ?>

                    </p>
                  </div>
                </div>
              </div>
     <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.pages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\KogiNewsBlog\resources\views/pages/single-post.blade.php ENDPATH**/ ?>