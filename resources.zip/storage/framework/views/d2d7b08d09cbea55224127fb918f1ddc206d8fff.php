

<?php $__env->startSection('content'); ?>




    <div class="content-wrapper">
      <div class="card">
<div class="card-body">
<h4 class="card-title">All Sport Post</h4>
<a href="/sport/create"> 
  <input type="submit" value="Create Sport Post" class="btn btn-primary ">
</a> 
<div class="row">
  <div class="col-12">
    <div class="table-responsive">
        <table id="order-listing" class="table">
          <?php if(count($sports)>0): ?>
          <thead>
            <tr>
              <th>s/n</th>
              <th>title </th>
              
              <th>EDIT FUNCTION</th>
              <th>DELETE FUNCTION</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $sports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($sport->id); ?></td>
              <td><?php echo e($sport->title); ?></td>
              

              <td>

               
                <a href="/sport/<?php echo e($sport->id); ?>/edit"> <button type="submit"  class="btn btn-primary ">EDIT </button></a> 

              </td>

              <td>

                <form action="/sport/<?php echo e($sport->id); ?>" method="POST">
                  <?php echo csrf_field(); ?>
              
                 <?php echo e(method_field('DELETE')); ?>

                
                 <button type="submit" name ="submit"  class="btn btn-danger">DELETE</button>
              </form>
              </td>
             
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             
          </tbody>
          <?php else: ?>
          <p>You Have no post</p>
          
          <?php endif; ?>
        </table>
         
        
      </div>
    </div>
</div>
</div>

    </div>
    
   
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\KogiNewsBlog\resources\views/sportview.blade.php ENDPATH**/ ?>