

<?php $__env->startSection('content'); ?>




    <div class="content-wrapper">
      <div class="card">
<div class="card-body">
<h4 class="card-title">All Politics Post</h4>
<a href="/politics/create"> 
  <input type="submit" value="Create Politics Post" class="btn btn-primary ">
</a> 
<div class="row">
  <div class="col-12">
    <div class="table-responsive">
        <table id="order-listing" class="table">
          <?php if(count($politics)>0): ?>
          <thead>
            <tr>
              <th>s/n</th>
              <th>title </th>
              <th>EDIT FUNCTION</th>
              <th>DELETE FUNCTION</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $politics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $politics): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($politics->id); ?></td>
              <td><?php echo e($politics->title); ?></td>
              

              <td>

               
                <a href="/politics/<?php echo e($politics->id); ?>/edit"> 
                  <input type="submit" value="edit" class="btn btn-primary ">
                </a> 
              
              </td>
              <td>

                <form action="/politics/<?php echo e($politics->id); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                 <?php echo e(method_field('DELETE')); ?>

                
                 <input type="submit" name ="submit" value ="delete" class="btn btn-danger">
              </form>
              </td>
             
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
          </tbody>
          <?php else: ?>
          <p>You Have no post</p>
          
          <?php endif; ?>
        </table>
         
        
      </div>
    </div>
</div>
</div>

    </div>
    
   
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\KogiNewsBlog\resources\views/politicsview.blade.php ENDPATH**/ ?>