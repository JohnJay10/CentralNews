

<?php $__env->startSection('content'); ?>




    <div class="content-wrapper">
      <div class="card">
<div class="card-body">
    <div class="d-flex justify-content-between">

      <h2 class="card-title">Recycle Bin </h2>

        <a href="<?php echo e(route('post.index')); ?>"> 
            <input type="submit" value="Back " class="btn btn-primary ">
        </a>
        

    </div> 
   
     <br><br>


<div class="row">  
  <div class="col-12">
    <div class="table-responsive">
        <table id="order-listing" class="table">
          <?php if(count($posts)>0): ?>
          <thead>
            <tr>
           
              <th>title </th>
              <th>slug </th>
              <th>EDIT FUNCTION</th>
              <th>DELETE FUNCTION</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              
              <td><?php echo e($post->name); ?></td>
              <td><?php echo e($post->slug); ?></td>
              

              <td>

                <div>
                  <form action="<?php echo e(route('post.restore', [$post->id])); ?>" method="post">
                      <?php echo csrf_field(); ?>
                      <button type="submit" class="btn btn-warning btn-sm rounded">
                          <i class="material-icons"></i>
                          Restore
                      </button>
                  </form>
                 </div>
              
              </td>
              <td>

                <form action="<?php echo e(route('post.force.delete', [$post->id])); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                 <?php echo e(method_field('DELETE')); ?>

                
                 <button type="submit" class="btn btn-danger btn-sm rounded">
                  <i class="material-icons"></i>
                  Force Delete
              </button>
              </form>
              </td>
             
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
          </tbody>
          <?php else: ?>


          <p>You Have no post</p>
          
          <?php endif; ?>
        </table>
         
        
      </div>
    </div>
</div>
</div>

    </div>
    
   
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\KogiNewsBlog\resources\views/post/trash.blade.php ENDPATH**/ ?>