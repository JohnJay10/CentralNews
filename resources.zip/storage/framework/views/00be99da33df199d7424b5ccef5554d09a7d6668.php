

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
    <div class="container">
      <div class="col-sm-12">
        <div class="card" data-aos="fade-up">
          <div class="card-body">
            <div class="row">
             
              <div class="col-sm-12">
                <h1 class="font-weight-600 mb-4">
                  <?php echo e($post->title); ?>

                </h1>
              </div>
            </div>
           
            <div class="row">
              <div class="col-lg-12">
                <div class="row">
                  <div class="col-sm-12 grid-margin">
                    <img style="width: 70%"
                    src="<?php echo e($post->url); ?>"
                    alt="banner"
                    class="img-fluid"
                  />
                  </div>
                  <div class="col-sm-12 grid-margin">
                 
                    <p class="fs-13 text-muted mb-0" ">
                      <span class="mr-2" >Posted </span><?php echo e($post->created_at->diffForHumans()); ?>

                    </p>
                    <p class="fs-15">
                      <?php echo $post->body; ?>

                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>


     
      <br><br>
      <div class="container">
     
    </div>
    <div class="card-body">
      <?php $__currentLoopData = $category_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php $__currentLoopData = $category->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($key === 0): ?>
      <div class="row">
        <div class="col-lg-8">
          <h2 class="cat">
          <div class="card-title">
           <?php echo e($category->name); ?>

          </div>
        </h2>
          <div class="row">
            <div class="col-sm-6 grid-margin">
              <div class="">
                <div class="rotate-img">
                  <img src="<?php echo e($item->url); ?>" style="height:100%;"alt="<?php echo e(route('single-post', [$item->slug])); ?>" class="img-fluid">
                </div>
                <div>
                  <p><?php echo e(str_limit( $item->preview, 50, '...')); ?></p>
                </div>
               
               
              </div>
            </div>
            <div class="col-sm-6 grid-margin">
              <div   grid-margin">
                  
                <a  style="font-size:20px;"href="<?php echo e(route('single-post', [$item->slug])); ?>">
                  <?php echo e($item->title); ?>

                </a>
             
              
              <div class="fs-13 mb-2">
                <span class="mr-2">Category </span><?php echo e($category->name); ?>

              </div>
              <div class="fs-13 mb-2">
                <span class="mr-2">Posted </span><?php echo e($item->created_at->diffForHumans()); ?>

              </div>
              
            </div>
            </div>
          </div>
        </div>
        <?php else: ?>
        <?php if($key === 1): ?>
        <div class="col-lg-4">
         
          <div class="d-flex justify-content-between align-items-center">
            <div class="card-title">
              <p style="font-weight: 700;">
                More <?php echo e($category->name); ?>

              </p>
             
            </div>
            <p class="mb-3">See all</p>
          </div>
          <?php endif; ?>
          <div class="d-flex justify-content-between align-items-center border-bottom pb-2">
            <div class="div-w-80 mr-3">
              <div class="rotate-img">
                <img src="<?php echo e($item->url); ?>" alt=" <?php echo e(route('single-post', [$item->slug])); ?> class="img-fluid style="height: 50px ">
              </div>
            </div>
            
              <a   style="font-size:15px;"href="<?php echo e(route('single-post', [$item->slug])); ?>">
                <?php echo e($item->title); ?></a>
           
          </div>
          <hr>
          <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        </div>
        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        <hr>
      </div>
      <hr>
     
    </div>
    </div>
  </div>




             
     <?php $__env->stopSection(); ?>


   

<?php echo $__env->make('layouts.pages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\KogiNewsBlog\resources\views/pages/single-post.blade.php ENDPATH**/ ?>