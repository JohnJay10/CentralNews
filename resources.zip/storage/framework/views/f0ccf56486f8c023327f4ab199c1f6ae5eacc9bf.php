
<?php $__env->startSection('content'); ?>
<style>
.navba{
  color:white;
}
.cat{
  font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
}
.post{
  font-family: Roboto;
}

</style>
<div class="content-wrapper">
    <div class="container">
      <div class="row" data-aos="fade-up">
        <div class="col-xl-8 stretch-card grid-margin">
          <?php if( count($latest) > 0 ): ?>
          <?php $__currentLoopData = $latest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single_post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="position-relative">
            <img style="max-height: 100%"
              src="<?php echo e($single_post->url); ?>"
              alt="banner"
              class="img-fluid"
            />
            <div class="banner-content">
              
              <h1 class="mb-0"><?php echo e($single_post->title); ?></h1>
              <h1 class="mb-2">
                
              </h1>
              
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php else: ?>
                <?php endif; ?>
        </div>
        <div class="col-xl-4 stretch-card grid-margin">
          <div class="card bg-dark text-white">
            
            <div class="card-body">
              <h2 style="font-family: Roboto;">Latest Post</h2>
                 <?php if( count($latestPost) > 0 ): ?>
                <?php $__currentLoopData = $latestPost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single_post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              
     
              <div
                class="d-flex border-bottom-blue pt-3 pb-4 align-items-center justify-content-between">
             
              
                <div class="pr-3">
                    
                    
                 
                  <h5 > 
                  
                   <a class="navba" style="font-size:14px color:white" href="<?php echo e(route('single-post', [$single_post->slug])); ?>">
                    <?php echo e($single_post->title); ?>  
                  </a>
                  </h5>
                  <div class="fs-12">
                    <span class="mr-2"></span>
                  </div>
                </div>
                <div class="rotate-img">
                  <img
                    src="<?php echo e($single_post->url); ?>"
                    alt="thumb"
                    class="img-fluid img-lg"
                    
                  />
                </div>
                
              </div>

               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php else: ?>
                <?php endif; ?>

              
            </div>
          </div>
        </div>
      </div>
      <div class="row" data-aos="fade-up">

        <div class="row" data-aos="fade-up">
          <div class="col-lg-3 stretch-card grid-margin">
            <div class="card">
              <div class="card-body">
                <h2>Category</h2>
                <ul class="vertical-menu">
                  
                  <li>
                    <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    
                      <h5 class="font-weight-600">
                        <a  href="<?php echo e(route('category-post', [$category->slug])); ?>"  >
                        <?php echo e($category->name); ?>

                      </a>
                      </h5>
                     
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
                  
                  </li>
                 
                  
                </ul>
              </div>
            </div>
          </div>

         
        <div class="col-lg-9 stretch-card grid-margin" id="pol_data">
          <div class="card">
            <div class="card-body">
              <?php if( count($posts) > 0 ): ?>
              <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
             
              <div class="row">
                <div class="col-sm-4 grid-margin">
                  <div class="position-relative">
                    <div class="rotate-img">
                      <img
                        src="<?php echo e(($post->url)); ?>"
                        alt="thumb"
                        class="img-fluid"
                      >
                    </div>
                    <div class="badge-positioned">
                     
                    
                    </div>
                  </div>
                </div>
                <div class="col-sm-8  grid-margin">
                  <h2 class=" font-weight-600">
                    <a  class="post" style="font-size:15px; font-weight:700;"href="<?php echo e(route('single-post', [$post->slug])); ?>">
                      <?php echo e($post->title); ?></a>
                  </h2>
                  <div class="fs-13 mb-2">
                    <span class="mr-2">Category </span><?php echo e($post->category->name); ?>

                  </div>
                  <div class="fs-13 mb-2">
                    <span class="mr-2">Posted </span><?php echo e(date('F,j,Y',strtotime($post->created_at))); ?>

                    
                  </div>
                  <p class="mb-0">
                    <?php echo e($post->preview); ?>


                  </p>
                </div>
               
              </div>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              <?php else: ?>
              <?php endif; ?>

             
            </div>
          </div>

         
        </div>
      </div>
      
     

      <div class="col-sm-12">
        <div class="card">
          <div class="card-body">
            <div class="row">
              <div class="col-xl-6">
                <div class="card-title">
                 FLASH NEWS
                </div>
                <div class="row">



                  <div class="col-xl-6 col-lg-8 col-sm-6">
                    <?php if( count($latest) > 0 ): ?>
                    <?php $__currentLoopData = $latest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single_post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="rotate-img">
                      <img src="<?php echo e($single_post->url); ?>" alt="thumb" class="img-fluid">
                    </div>
                    <h2 style="font-size:20px"class="mt-3 text-primary mb-2">
                      <a class="navba" style=" color:black" href="<?php echo e(route('single-post', [$single_post->slug])); ?>">
                        <?php echo e($single_post->title); ?>  
                      </a>
                    </h2>
                    <p class="fs-13 mb-1 text-muted">
                      <span class="mr-2">Posted </span><?php echo e($post->created_at->diffForHumans()); ?>

                    </p>
                    <p class="my-3 fs-15">
                      <?php echo e($single_post->preview); ?>

                    </p>
                    <a href="#" class="font-weight-600 fs-16 text-dark">Read more</a>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  <?php else: ?>
                  <?php endif; ?>

                 
                  <div class="col-xl-6 col-lg-4 col-sm-6">
                    <div class="card-title">
                      MOST VIEWED
                     </div>
                     <?php if( count($mostviewed) > 0 ): ?>
                    <?php $__currentLoopData = $mostviewed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single_post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="border-bottom pb-3 mb-3">
                      <h3 class="font-weight-600 mb-0">
                        <a class="navba" style=" color:black; font-size:15px;" href="<?php echo e(route('single-post', [$single_post->slug])); ?>">
                          <?php echo e($single_post->title); ?>  
                        </a>
                      </h3>
                      <p class="fs-13 text-muted mb-0">
                        <span class="mr-2">Photo </span><?php echo e($post->created_at->diffForHumans()); ?>

                      </p>
                      
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php else: ?>
                    <?php endif; ?>
                   
                    
                
                  </div>
                </div>
              </div>
              <div class="col-xl-6">
                <div class="row">
                  
                  <div class="col-sm-6">
                    
                    <div class="row">
                      
                    
                    
                    
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

            <div class="card-body">
              <?php $__currentLoopData = $category_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php $__currentLoopData = $category->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($key === 0): ?>
              <div class="row">
                <div class="col-lg-8">
                  <h2 class="cat">
                  <div class="card-title">
                   <?php echo e($category->name); ?>

                  </div>
                </h2>
                  <div class="row">
                    <div class="col-sm-6 grid-margin">
                      <div class="">
                        <div class="rotate-img">
                          <img src="<?php echo e($item->url); ?>" style="height:100%;"alt="<?php echo e(route('single-post', [$item->slug])); ?>" class="img-fluid">
                        </div>
                        <div>
                          <p><?php echo e(str_limit( $item->preview, 50, '...')); ?></p>
                        </div>
                       
                       
                      </div>
                    </div>
                    <div class="col-sm-6 grid-margin">
                      <div   grid-margin">
                          
                        <a  style="font-size:20px;"href="<?php echo e(route('single-post', [$item->slug])); ?>">
                          <?php echo e($item->title); ?>

                        </a>
                     
                      
                      <div class="fs-13 mb-2">
                        <span class="mr-2">Category </span><?php echo e($category->name); ?>

                      </div>
                      <div class="fs-13 mb-2">
                        <span class="mr-2">Posted </span><?php echo e($item->created_at->diffForHumans()); ?>

                      </div>
                      
                    </div>
                    </div>
                  </div>
                </div>
                <?php else: ?>
                <?php if($key === 1): ?>
                <div class="col-lg-4">
                 
                  <div class="d-flex justify-content-between align-items-center">
                    <div class="card-title">
                      <p style="font-weight: 700;">
                        More <?php echo e($category->name); ?>

                      </p>
                     
                    </div>
                 
                  </div>
                  <?php endif; ?>
                  <div class="d-flex justify-content-between align-items-center border-bottom pb-2">
                    <div class="div-w-80 mr-3">
                      <div class="rotate-img">
                        <img src="<?php echo e($item->url); ?>" alt=" <?php echo e(route('single-post', [$item->slug])); ?> class="img-fluid style="height: 50px ">
                      </div>
                    </div>
                    
                      <a   style="font-size:15px;"href="<?php echo e(route('single-post', [$item->slug])); ?>">
                        <?php echo e($item->title); ?></a>
                   
                  </div>
                  <hr>
                  <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                </div>
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                <hr>
              </div>
              <hr>
             
            </div>
    </div>
  </div>
  
  <script>
      
      $(document).ready(function(){
       $(document).on('click','.pagination a', function(event){
           
           event.preventDefault();
           var page = $(this).attr('href').split('page=')[1];
           getmorepol(page);
       });
          
      });
      
      
      function getmorepol(page){
          $.ajax({
              type: "GET",
              url: "<?php echo e(route('get-more-pol')); ?>",
              success: function(data){
               $('#pol_data'). html(data); 
                  
              }
          })
      }
  </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.pages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\KogiNewsBlog\resources\views/pages/index.blade.php ENDPATH**/ ?>