 

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
    <div class="container">
      <div class="col-sm-12">
        <div class="card" data-aos="fade-up">
          <div class="card-body">
            <div class="row">
              <div class="col-sm-12">
                <h1 class="font-weight-600 mb-4">
                  SPORT
                </h1>
              </div>
            </div>
        
            <div class="row">
              <div class="col-lg-8">
                <?php if( count($sports) > 0 ): ?>
                <?php $__currentLoopData = $sports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row">
                 
                  <div class="col-sm-4 grid-margin">
                    <div class="rotate-img">
                      <img
                        src="/storage/image/<?php echo e($sport->image); ?>"
                        alt="banner"
                        class="img-fluid"
                      />
                    </div>
                  </div>
                  <div class="col-sm-8 grid-margin">
                    <h2 class="font-weight-600 mb-2">
                      <a class="navbar" href="/sport/<?php echo e($sport->id); ?>">
                      <?php echo e($sport-> title); ?></a>
                      
                    </h2>
                    <p class="fs-13 text-muted mb-0">
                      <span class="mr-2">Photo </span><?php echo e($sport -> created_at); ?>

                    </p>
                    <p class="fs-15">
                      <?php echo e($sport-> body); ?>

                    </p>
                   
                  </div>
               
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php else: ?>
                <?php endif; ?>
                <?php echo e($sports->links()); ?>

              </div>
             
            
              
              <div class="col-lg-4">
                <h2 class="mb-4 text-primary font-weight-600">
                  Latest news
                </h2>
                <div class="row">
                  <div class="col-sm-12">
                    <div class="border-bottom pb-4 pt-4">
                      <div class="row">
                        <?php if( count($latestnews) > 0 ): ?>
                         <?php $__currentLoopData = $latestnews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $latestnews): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-8">
                          
                          <h5 class="font-weight-600 mb-1">
                            <?php echo e($latestnews-> title); ?>

                          </h5>
                          <p class="fs-13 text-muted mb-0">
                            <span class="mr-2">Photo </span><?php echo e($latestnews-> created_at); ?>

                          </p>
                        </div>
                        <div class="col-sm-4">
                          <div class="rotate-img">
                            <img
                              src="/storage/image/<?php echo e($latestnews->image); ?>"
                              alt="banner"
                              class="img-fluid"
                            />
                          </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php else: ?>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                </div>
                
                
                <div class="trending">
                  <h2 class="mb-4 text-primary font-weight-600">
                    Trending
                  </h2>
                  <div class="mb-4">
                    <div class="rotate-img">
                      <img
                        src="../site/assets/images/politics/Politics_4.jpg"
                        alt="banner"
                        class="img-fluid"
                      />
                    </div>
                    <h3 class="mt-3 font-weight-600">
                      Virus Kills Member Of Advising Iran’s Supreme
                    </h3>
                    <p class="fs-13 text-muted mb-0">
                      <span class="mr-2">Photo </span>10 Minutes ago
                    </p>
                  </div>
                  <div class="mb-4">
                    <div class="rotate-img">
                      <img
                        src="../site/assets/images/politics/Politics_5.jpg"
                        alt="banner"
                        class="img-fluid"
                      />
                    </div>
                    <h3 class="mt-3 font-weight-600">
                      Virus Kills Member Of Advising Iran’s Supreme
                    </h3>
                    <p class="fs-13 text-muted mb-0">
                      <span class="mr-2">Photo </span>10 Minutes ago
                    </p>
                  </div>
                  <div class="mb-4">
                    <div class="mb-4">
                      <div class="rotate-img">
                        
                        <img
                          src="..site/assets/images/politics/Politics_6.jpg"
                          alt="banner"
                          class="img-fluid"
                        />
                      </div>
                    <h3 class="mt-3 font-weight-600">
                      Virus Kills Member Of Advising Iran’s Supreme
                    </h3>
                    <p class="fs-13 text-muted mb-0">
                      <span class="mr-2">Photo </span>10 Minutes ago
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.pages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\KogiNewsBlog\resources\views/sport/index.blade.php ENDPATH**/ ?>