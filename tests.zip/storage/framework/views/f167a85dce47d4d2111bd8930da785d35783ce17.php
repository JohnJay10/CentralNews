

<?php $__env->startSection('content'); ?>




    <div class="content-wrapper">
      <div class="card">
<div class="card-body">
    <div class="d-flex justify-content-between">

      <h2 class="card-title">Recycle Bin </h2>

        <a href="<?php echo e(route('category.index')); ?>"> 
            <input type="submit" value="Back " class="btn btn-primary ">
        </a>
        

    </div> 
   
     <br><br>


<div class="row">  
  <div class="col-12">
    <div class="table-responsive">
        <table id="order-listing" class="table">
          <?php if(count($categories)>0): ?>
          <thead>
            <tr>
           
              <th>title </th>
              <th>slug </th>
              <th>EDIT FUNCTION</th>
              <th>DELETE FUNCTION</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              
              <td><?php echo e($category->name); ?></td>
              <td><?php echo e($category->slug); ?></td>
              

              <td>

                <div>
                  <form action="<?php echo e(route('category.restore', [$category->id])); ?>" method="post">
                      <?php echo csrf_field(); ?>
                      <button type="submit" class="btn btn-warning btn-sm rounded">
                          <i class="material-icons"></i>
                          Restore
                      </button>
                  </form>
                 </div>
              
              </td>
              <td>

                <form action="<?php echo e(route('category.force.delete', [$category->id])); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                 <?php echo e(method_field('DELETE')); ?>

                
                 <button type="submit" class="btn btn-danger btn-sm rounded">
                  <i class="material-icons"></i>
                  Force Delete
              </button>
              </form>
              </td>
             
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
          </tbody>
          <?php else: ?>


          <p>You Have no post</p>
          
          <?php endif; ?>
        </table>
         
        
      </div>
    </div>
</div>
</div>

    </div>
    
   
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\KogiNewsBlog\resources\views/category/trash.blade.php ENDPATH**/ ?>