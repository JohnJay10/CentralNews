

<?php $__env->startSection('content'); ?>
<div class="col-12 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        
        <h3 class="card-description" style="font: 500;">
        Update <?php echo e($post->title); ?>

        </h3>
        <form class="forms-sample" method="post" action="<?php echo e(route('post.update', $post->id)); ?>" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('PATCH')); ?>

          <div class="form-group">   
            <label for="exampleInputName1">Name</label>
            <input type="text" class="form-control" id="exampleInputName1"  value="<?php echo e($post->title); ?>"placeholder="Enter post Name" name="title" required>
          </div>

          <div class="form-group">   
            <label for="exampleInputName1">Content Here</label>
            <textarea
            name="post_content"
            placeholder="Please type your content here"
            id="post_content"
            class="form-control"
            cols="30"
            rows="10"
            ><?php echo e($post->body); ?></textarea>
          </div>

          <div class="form-group">
            <label for="preview">Preview Here</label>
            <textarea
                name="preview"
                id="preview"
                class="form-control"
            ><?php echo e($post->preview); ?> </textarea>
        </div>

          <div class="form-group">
            <label for="category_id">Select Category</label>
            <select name="category_id" id="category_id" class="form-control">
                <option value="0">Please Select Category</option>
                <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <option value="<?php echo e($category->id); ?>"
                      <?php if($post->category_id == $category->id): ?>
                        selected
                        <?php endif; ?>
                      ><?php echo e($category->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
            </select>
        </div>

        <div class="form-file-group">
          <input type="file"
                 name="feature_image"
                 style="display: none"
                 id="file-upload"
                 onchange="previewFile(this)">
          <p onclick="document.querySelector('#file-upload').click()">
              Drag Your File Here or Click in this area to Upload
          </p>
      </div>
      <div id="previewBox" style="display: none">
          <img src="<?php echo e($post->url); ?>" id="previewImg" width="500px" class="img-fluid">
          <i
              class="material-icons"
              style="cursor: pointer"
              onclick="removePreview()"
          >delete</i>
      </div>
      <br><br>
        
      <?php if($post->status == 'draft'): ?>
      <button
          class="btn btn-primary rounded"
          type="submit" value="draft" name="status">Save Post</button>
  <?php endif; ?>
  <?php if($post->status == 'publish'): ?>
      <button
          class="btn btn-success rounded"
          type="submit" value="publish" name="status">Update Post</button>
  <?php else: ?>
      <button
          class="btn btn-success rounded"
          type="submit" value="publish" name="status">Publish Post</button>
  <?php endif; ?>
          
        </form>
      </div>
    </div>
  </div>

  <script>

$(document).ready(function (){
           let url = "<?php echo e($post->url); ?>";
           if(url !== ""){
               $("#previewBox").css('display', 'block');
               $(".form-file-group").css('display', 'none');
           }
        });
  </script>
  
  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <style>
        .form-file-group{
            width: 500px;
            height: 200px;
            border: 4px dashed #000;
        }
        .form-file-group p {
            width: 100%;
            height: 100%;
            text-align: center;
            line-height: 170px;
        }
    </style>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\KogiNewsBlog\resources\views/post/edit.blade.php ENDPATH**/ ?>