

<?php $__env->startSection('content'); ?>




    <div class="content-wrapper">
      <div class="card">
<div class="card-body">
<h4 class="card-title">All Politics Post</h4>
<a href="/latestnews/create"> 
  <input type="submit" value="Create Latestnews Post" class="btn btn-primary ">
</a> 
<div class="row">
  <div class="col-12">
    <div class="table-responsive">
        <table id="order-listing" class="table">
          <?php if(count($latestnews)>0): ?>
          <thead>
            <tr>
              <th>s/n</th>
              <th>title </th>
              <th>EDIT FUNCTION</th>
              <th>DELETE FUNCTION</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $latestnews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $latestnews): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td></td>
              <td><?php echo e($latestnews->title); ?></td>
              

              <td>

               
                <a href="/latestnews/<?php echo e($latestnews->id); ?>/edit"> 
                  <input type="submit"  value = "edit"class="btn btn-primary "> 
                </a> 

              </td>
              <td>
                
                <form action="/latestnews/<?php echo e($latestnews->id); ?>" method="POST">
                  <?php echo csrf_field(); ?>
              
                 <?php echo e(method_field('DELETE')); ?>

                
                 <input type="submit" name ="submit" value="delete" class="btn btn-danger">
              </form>
              </td>
             
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
          </tbody>
          <?php else: ?>
          <p>You Have no post</p>
          
          <?php endif; ?>
        </table>
         
        
      </div>
    </div>
</div>
</div>

    </div>
    
   
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\KogiNewsBlog\resources\views/latestnewsview.blade.php ENDPATH**/ ?>