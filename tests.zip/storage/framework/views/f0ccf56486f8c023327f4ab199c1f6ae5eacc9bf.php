
<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
    <div class="container">
      <div class="row" data-aos="fade-up">
        <div class="col-xl-8 stretch-card grid-margin">
          <?php if( count($latest) > 0 ): ?>
          <?php $__currentLoopData = $latest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single_post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="position-relative">
            <img style="max-height: 100%"
              src="<?php echo e($single_post->url); ?>"
              alt="banner"
              class="img-fluid"
            />
            <div class="banner-content">
              
              <h1 class="mb-0"><?php echo e($single_post->title); ?></h1>
              <h1 class="mb-2">
                
              </h1>
              
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php else: ?>
                <?php endif; ?>
        </div>
        <div class="col-xl-4 stretch-card grid-margin">
          <div class="card bg-dark text-white">
            
            <div class="card-body">
              <h2>Latest news</h2>
                 <?php if( count($latestPost) > 0 ): ?>
                <?php $__currentLoopData = $latestPost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single_post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              
     
              <div
                class="d-flex border-bottom-blue pt-3 pb-4 align-items-center justify-content-between">
             
              
                <div class="pr-3">
                    
                    
                 
                  <h5 > 
                  
                   <a class="navba" style="font-size:14px" href="<?php echo e(route('single-post', [$single_post->slug])); ?>">
                    <?php echo e($single_post->title); ?>  
                  </a>
                  </h5>
                  <div class="fs-12">
                    <span class="mr-2"></span>
                  </div>
                </div>
                <div class="rotate-img">
                  <img
                    src="<?php echo e($single_post->url); ?>"
                    alt="thumb"
                    class="img-fluid img-lg"
                    
                  />
                </div>
                
              </div>

               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php else: ?>
                <?php endif; ?>

              
            </div>
          </div>
        </div>
      </div>
      <div class="row" data-aos="fade-up">

        <div class="row" data-aos="fade-up">
          <div class="col-lg-3 stretch-card grid-margin">
            <div class="card">
              <div class="card-body">
                <h2>Category</h2>
                <ul class="vertical-menu">
                  
                  <li>
                    <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <a  href="<?php echo e(route('category-post', [$category->slug])); ?>"  >
                      <h5 class="font-weight-600">
                        <?php echo e($category->name); ?>

                      </h5>
                      </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
                  
                  </li>
                 
                  
                </ul>
              </div>
            </div>
          </div>

         
        <div class="col-lg-9 stretch-card grid-margin" id="pol_data">
          <div class="card">
            <div class="card-body">
              <?php if( count($posts) > 0 ): ?>
              <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
             
              <div class="row">
                <div class="col-sm-4 grid-margin">
                  <div class="position-relative">
                    <div class="rotate-img">
                      <img
                        src="<?php echo e(($post->url)); ?>"
                        alt="thumb"
                        class="img-fluid"
                      >
                    </div>
                    <div class="badge-positioned">
                     
                    
                    </div>
                  </div>
                </div>
                <div class="col-sm-8  grid-margin">
                  <h2 class="mb-2 font-weight-600">
                    <a class="navbar" href="<?php echo e(route('single-post', [$post->slug])); ?>">
                      <?php echo e($post->title); ?></a>
                  </h2>
                  <div class="fs-13 mb-2">
                    <span class="mr-2">Category </span><?php echo e($post->category->name); ?>

                  </div>
                  <div class="fs-13 mb-2">
                    <span class="mr-2">Posted </span><?php echo e($post->created_at->diffForHumans()); ?>

                  </div>
                  <p class="mb-0">
                    <?php echo e($post->preview); ?>


                  </p>
                </div>
               
              </div>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              <?php else: ?>
              <?php endif; ?>

             
            </div>
          </div>

         
        </div>
      </div>
      
      <div class="row" data-aos="fade-up">
        <div class="col-sm-12">
          <div class="card">
            <div class="card-body">
              <div class="row">
                
                <div class="col-xl-6">
                       <div class="card-title">
                  <h1>Latest News</h1>
                  </div>
                  <?php if( count($latestPost) > 0 ): ?>
                  <?php $__currentLoopData = $latestPost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single_post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 
                  <div class="row">
                   
                    <div class="col-xl-6 col-lg-8 col-sm-6">
                  
                      <div class="rotate-img">
                        <img
                          src="<?php echo e($single_post->url); ?>"
                          alt="thumb"
                          class="img-fluid"
                        />
                      </div>
                    
                    </div>
                    <div class="col-xl-6 col-lg-4 col-sm-6">
                  
                      <div class="border-bottom pb-3 mb-3">
                       <a href="<?php echo e(route('single-post', [$single_post->slug])); ?>"><h3 class="font-weight-600 mb-0">
                        <?php echo e($single_post->title); ?>

                       </h3></a> 
                        
                        <p class="fs-13 text-muted mb-0">
                          <span class="mr-2">posted </span><?php echo e($post->created_at->diffForHumans()); ?>

                        </p>
                        
                      </div>
                      
                      
                      
                 
                    </div>
                   
                  </div>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php else: ?>
                    <?php endif; ?> 
                </div>
                <div class="col-xl-6">
                  <div class="row">
                    
                    <div class="col-sm-6">
                      
                      <div class="card-title">
                      LATEST NEWS
                      </div>
                      <div class="border-bottom pb-3">
                        <div class="rotate-img">
                          <img
                            src="/assets/images/latest.webp"
                            alt="thumb"
                            class="img-fluid"
                          />
                        </div>
                        <p class="fs-16 font-weight-600 mb-0 mt-3">
                             2022 World Cup: Morocco qualify as Group winners after 2-1 win over Canada
                        </p>
                        <p class="fs-13 text-muted mb-0">
                          <span class="mr-2"> </span>
                        </p>
                      </div>
                      <div class="pt-3 pb-3">
                        <div class="rotate-img">
                          <img
                            src="/assets/images/j.webp"
                            alt="thumb"
                            class="img-fluid"
                          />
                        </div>
                        <p class="fs-16 font-weight-600 mb-0 mt-3">
                          I didn’t say Peter Odili was my classmate – Obi
                        </p>
                        <p class="fs-13 text-muted mb-0">
                          <span class="mr-2">
                        </p>
                      </div>
                    </div>
                    <div class="col-sm-6">
                      <div class="card-title">
                       SPONSOR ADS
                      </div>
                      <div class="row">
                        <div class="col-sm-12">
                            
                          <!--<div class="border-bottom pb-3">-->
                          <!--  <div class="row">-->
                          <!--    <div class="col-sm-5 pr-2">-->
                          <!--      <div class="rotate-img">-->
                          <!--        <img-->
                          <!--          src="/site/assets/images/dashboard/home_19.jpg"-->
                          <!--          alt="thumb"-->
                          <!--          class="img-fluid w-100"-->
                          <!--        />-->
                          <!--      </div>-->
                          <!--    </div>-->
                          <!--    <div class="col-sm-7 pl-2">-->
                          <!--      <p class="fs-16 font-weight-600 mb-0">-->
                          <!--        Online shopping ..-->
                          <!--      </p>-->
                          <!--      <p class="fs-13 text-muted mb-0">-->
                          <!--        <span class="mr-2">Photo </span>10-->
                          <!--        Minutes ago-->
                          <!--      </p>-->
                          <!--      <p class="mb-0 fs-13">-->
                          <!--        Lorem Ipsum has been-->
                          <!--      </p>-->
                          <!--    </div>-->
                          <!--  </div>-->
                          <!--</div>-->
                        </div>
                      </div>
                      <!--<div class="row">-->
                      <!--  <div class="col-sm-12">-->
                      <!--    <div class="border-bottom pb-3 pt-3">-->
                      <!--      <div class="row">-->
                      <!--        <div class="col-sm-5 pr-2">-->
                      <!--          <div class="rotate-img">-->
                      <!--            <img-->
                      <!--              src="/site/assets/images/dashboard/home_20.jpg"-->
                      <!--              alt="thumb"-->
                      <!--              class="img-fluid w-100"-->
                      <!--            />-->
                      <!--          </div>-->
                      <!--        </div>-->
                      <!--        <div class="col-sm-7 pl-2">-->
                      <!--          <p class="fs-16 font-weight-600 mb-0">-->
                      <!--            Online shopping ..-->
                      <!--          </p>-->
                      <!--          <p class="fs-13 text-muted mb-0">-->
                      <!--            <span class="mr-2">Photo </span>10-->
                      <!--            Minutes ago-->
                      <!--          </p>-->
                      <!--          <p class="mb-0 fs-13">-->
                      <!--            Lorem Ipsum has been-->
                      <!--          </p>-->
                      <!--        </div>-->
                      <!--      </div>-->
                      <!--    </div>-->
                      <!--  </div>-->
                      <!--</div>-->
                      <!--<div class="row">-->
                      <!--  <div class="col-sm-12">-->
                      <!--    <div class="border-bottom pb-3 pt-3">-->
                      <!--      <div class="row">-->
                      <!--        <div class="col-sm-5 pr-2">-->
                      <!--          <div class="rotate-img">-->
                      <!--            <img-->
                      <!--              src="/site/assets/images/dashboard/home_21.jpg"-->
                      <!--              alt="thumb"-->
                      <!--              class="img-fluid w-100"-->
                      <!--            />-->
                      <!--          </div>-->
                      <!--        </div>-->
                      <!--        <div class="col-sm-7 pl-2">-->
                      <!--          <p class="fs-16 font-weight-600 mb-0">-->
                      <!--            Online shopping ..-->
                      <!--          </p>-->
                      <!--          <p class="fs-13 text-muted mb-0">-->
                      <!--            <span class="mr-2">Photo </span>10-->
                      <!--            Minutes ago-->
                      <!--          </p>-->
                      <!--          <p class="mb-0 fs-13">-->
                      <!--            Lorem Ipsum has been-->
                      <!--          </p>-->
                      <!--        </div>-->
                      <!--      </div>-->
                      <!--    </div>-->
                      <!--  </div>-->
                      <!--</div>-->
                      <!--<div class="row">-->
                      <!--  <div class="col-sm-12">-->
                      <!--    <div class="pt-3">-->
                      <!--      <div class="row">-->
                      <!--        <div class="col-sm-5 pr-2">-->
                      <!--          <div class="rotate-img">-->
                      <!--            <img-->
                      <!--              src="/site/assets/images/dashboard/home_22.jpg"-->
                      <!--              alt="thumb"-->
                      <!--              class="img-fluid w-100"-->
                      <!--            />-->
                      <!--          </div>-->
                      <!--        </div>-->
                      <!--        <div class="col-sm-7 pl-2">-->
                      <!--          <p class="fs-16 font-weight-600 mb-0">-->
                      <!--            Online shopping ..-->
                      <!--          </p>-->
                      <!--          <p class="fs-13 text-muted mb-0">-->
                      <!--            <span class="mr-2">Photo </span>10-->
                      <!--            Minutes ago-->
                      <!--          </p>-->
                      <!--          <p class="mb-0 fs-13">-->
                      <!--            Lorem Ipsum has been-->
                      <!--          </p>-->
                      <!--        </div>-->
                      <!--      </div>-->
                      <!--    </div>-->
                      <!--  </div>-->
                      <!--</div>-->
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  <script>
      
      $(document).ready(function(){
       $(document).on('click','.pagination a', function(event){
           
           event.preventDefault();
           var page = $(this).attr('href').split('page=')[1];
           getmorepol(page);
       });
          
      });
      
      
      function getmorepol(page){
          $.ajax({
              type: "GET",
              url: "<?php echo e(route('get-more-pol')); ?>",
              success: function(data){
               $('#pol_data'). html(data); 
                  
              }
          })
      }
  </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.pages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\KogiNewsBlog\resources\views/pages/index.blade.php ENDPATH**/ ?>