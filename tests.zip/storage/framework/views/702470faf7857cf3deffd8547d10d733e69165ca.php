

<?php $__env->startSection('content'); ?>
<div class="col-12 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        
        <h3 class="card-description" style="font: 500;">
         Create a New Category
        </h3>
        <form class="forms-sample" method="POST" action="<?php echo e(route('category.store')); ?>" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

          <div class="form-group">   
            <label for="exampleInputName1">Name</label>
            <input type="text" class="form-control" id="exampleInputName1" placeholder="Enter Category Name" name="name" required>
          </div>
        
          <button type="submit" class="btn btn-primary mr-2">Submit</button>
          
        </form>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\KogiNewsBlog\resources\views/category/create.blade.php ENDPATH**/ ?>