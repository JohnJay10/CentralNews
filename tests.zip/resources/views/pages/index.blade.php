@extends('layouts.pages')
@section('content')

<div class="content-wrapper">
    <div class="container">
      <div class="row" data-aos="fade-up">
        <div class="col-xl-8 stretch-card grid-margin">
          @if( count($latest) > 0 )
          @foreach($latest as $single_post)
          <div class="position-relative">
            <img style="max-height: 100%"
              src="{{$single_post->url}}"
              alt="banner"
              class="img-fluid"
            />
            <div class="banner-content">
              
              <h1 class="mb-0">{{$single_post->title}}</h1>
              <h1 class="mb-2">
                
              </h1>
              
            </div>
          </div>
          @endforeach

                @else
                @endif
        </div>
        <div class="col-xl-4 stretch-card grid-margin">
          <div class="card bg-dark text-white">
            
            <div class="card-body">
              <h2>Latest news</h2>
                 @if( count($latestPost) > 0 )
                @foreach($latestPost as $single_post)
              
     
              <div
                class="d-flex border-bottom-blue pt-3 pb-4 align-items-center justify-content-between">
             
              
                <div class="pr-3">
                    
                    
                 
                  <h5 > 
                  
                   <a class="navba" style="font-size:14px" href="{{route('single-post', [$single_post->slug])}}">
                    {{$single_post->title}}  
                  </a>
                  </h5>
                  <div class="fs-12">
                    <span class="mr-2"></span>
                  </div>
                </div>
                <div class="rotate-img">
                  <img
                    src="{{$single_post->url}}"
                    alt="thumb"
                    class="img-fluid img-lg"
                    
                  />
                </div>
                
              </div>

               @endforeach

                @else
                @endif

              
            </div>
          </div>
        </div>
      </div>
      <div class="row" data-aos="fade-up">

        <div class="row" data-aos="fade-up">
          <div class="col-lg-3 stretch-card grid-margin">
            <div class="card">
              <div class="card-body">
                <h2>Category</h2>
                <ul class="vertical-menu">
                  
                  <li>
                    @forelse($categories as $category)
                    <a  href="{{route('category-post', [$category->slug])}}"  >
                      <h5 class="font-weight-600">
                        {{$category->name}}
                      </h5>
                      </a>
                @empty
                @endforelse
                  
                  </li>
                 
                  
                </ul>
              </div>
            </div>
          </div>

         
        <div class="col-lg-9 stretch-card grid-margin" id="pol_data">
          <div class="card">
            <div class="card-body">
              @if( count($posts) > 0 )
              @foreach($posts as $post)
            
             
              <div class="row">
                <div class="col-sm-4 grid-margin">
                  <div class="position-relative">
                    <div class="rotate-img">
                      <img
                        src="{{ ($post->url)}}"
                        alt="thumb"
                        class="img-fluid"
                      >
                    </div>
                    <div class="badge-positioned">
                     
                    
                    </div>
                  </div>
                </div>
                <div class="col-sm-8  grid-margin">
                  <h2 class="mb-2 font-weight-600">
                    <a class="navbar" href="{{route('single-post', [$post->slug])}}">
                      {{$post->title}}</a>
                  </h2>
                  <div class="fs-13 mb-2">
                    <span class="mr-2">Category </span>{{$post->category->name}}
                  </div>
                  <div class="fs-13 mb-2">
                    <span class="mr-2">Posted </span>{{$post->created_at->diffForHumans()}}
                  </div>
                  <p class="mb-0">
                    {{$post->preview}}

                  </p>
                </div>
               
              </div>

              @endforeach

              @else
              @endif

             
            </div>
          </div>

         
        </div>
      </div>
      
      <div class="row" data-aos="fade-up">
        <div class="col-sm-12">
          <div class="card">
            <div class="card-body">
              <div class="row">
                
                <div class="col-xl-6">
                       <div class="card-title">
                  <h1>Latest News</h1>
                  </div>
                  @if( count($latestPost) > 0 )
                  @foreach($latestPost as $single_post)
                 
                  <div class="row">
                   
                    <div class="col-xl-6 col-lg-8 col-sm-6">
                  
                      <div class="rotate-img">
                        <img
                          src="{{$single_post->url}}"
                          alt="thumb"
                          class="img-fluid"
                        />
                      </div>
                    
                    </div>
                    <div class="col-xl-6 col-lg-4 col-sm-6">
                  
                      <div class="border-bottom pb-3 mb-3">
                       <a href="{{route('single-post', [$single_post->slug])}}"><h3 class="font-weight-600 mb-0">
                        {{$single_post->title}}
                       </h3></a> 
                        
                        <p class="fs-13 text-muted mb-0">
                          <span class="mr-2">posted </span>{{$post->created_at->diffForHumans()}}
                        </p>
                        
                      </div>
                      
                      
                      
                 
                    </div>
                   
                  </div>
                   @endforeach

                    @else
                    @endif 
                </div>
                <div class="col-xl-6">
                  <div class="row">
                    
                    <div class="col-sm-6">
                      
                      <div class="card-title">
                      LATEST NEWS
                      </div>
                      <div class="border-bottom pb-3">
                        <div class="rotate-img">
                          <img
                            src="/assets/images/latest.webp"
                            alt="thumb"
                            class="img-fluid"
                          />
                        </div>
                        <p class="fs-16 font-weight-600 mb-0 mt-3">
                             2022 World Cup: Morocco qualify as Group winners after 2-1 win over Canada
                        </p>
                        <p class="fs-13 text-muted mb-0">
                          <span class="mr-2"> </span>
                        </p>
                      </div>
                      <div class="pt-3 pb-3">
                        <div class="rotate-img">
                          <img
                            src="/assets/images/j.webp"
                            alt="thumb"
                            class="img-fluid"
                          />
                        </div>
                        <p class="fs-16 font-weight-600 mb-0 mt-3">
                          I didn’t say Peter Odili was my classmate – Obi
                        </p>
                        <p class="fs-13 text-muted mb-0">
                          <span class="mr-2">
                        </p>
                      </div>
                    </div>
                    <div class="col-sm-6">
                      <div class="card-title">
                       SPONSOR ADS
                      </div>
                      <div class="row">
                        <div class="col-sm-12">
                            
                          <!--<div class="border-bottom pb-3">-->
                          <!--  <div class="row">-->
                          <!--    <div class="col-sm-5 pr-2">-->
                          <!--      <div class="rotate-img">-->
                          <!--        <img-->
                          <!--          src="/site/assets/images/dashboard/home_19.jpg"-->
                          <!--          alt="thumb"-->
                          <!--          class="img-fluid w-100"-->
                          <!--        />-->
                          <!--      </div>-->
                          <!--    </div>-->
                          <!--    <div class="col-sm-7 pl-2">-->
                          <!--      <p class="fs-16 font-weight-600 mb-0">-->
                          <!--        Online shopping ..-->
                          <!--      </p>-->
                          <!--      <p class="fs-13 text-muted mb-0">-->
                          <!--        <span class="mr-2">Photo </span>10-->
                          <!--        Minutes ago-->
                          <!--      </p>-->
                          <!--      <p class="mb-0 fs-13">-->
                          <!--        Lorem Ipsum has been-->
                          <!--      </p>-->
                          <!--    </div>-->
                          <!--  </div>-->
                          <!--</div>-->
                        </div>
                      </div>
                      <!--<div class="row">-->
                      <!--  <div class="col-sm-12">-->
                      <!--    <div class="border-bottom pb-3 pt-3">-->
                      <!--      <div class="row">-->
                      <!--        <div class="col-sm-5 pr-2">-->
                      <!--          <div class="rotate-img">-->
                      <!--            <img-->
                      <!--              src="/site/assets/images/dashboard/home_20.jpg"-->
                      <!--              alt="thumb"-->
                      <!--              class="img-fluid w-100"-->
                      <!--            />-->
                      <!--          </div>-->
                      <!--        </div>-->
                      <!--        <div class="col-sm-7 pl-2">-->
                      <!--          <p class="fs-16 font-weight-600 mb-0">-->
                      <!--            Online shopping ..-->
                      <!--          </p>-->
                      <!--          <p class="fs-13 text-muted mb-0">-->
                      <!--            <span class="mr-2">Photo </span>10-->
                      <!--            Minutes ago-->
                      <!--          </p>-->
                      <!--          <p class="mb-0 fs-13">-->
                      <!--            Lorem Ipsum has been-->
                      <!--          </p>-->
                      <!--        </div>-->
                      <!--      </div>-->
                      <!--    </div>-->
                      <!--  </div>-->
                      <!--</div>-->
                      <!--<div class="row">-->
                      <!--  <div class="col-sm-12">-->
                      <!--    <div class="border-bottom pb-3 pt-3">-->
                      <!--      <div class="row">-->
                      <!--        <div class="col-sm-5 pr-2">-->
                      <!--          <div class="rotate-img">-->
                      <!--            <img-->
                      <!--              src="/site/assets/images/dashboard/home_21.jpg"-->
                      <!--              alt="thumb"-->
                      <!--              class="img-fluid w-100"-->
                      <!--            />-->
                      <!--          </div>-->
                      <!--        </div>-->
                      <!--        <div class="col-sm-7 pl-2">-->
                      <!--          <p class="fs-16 font-weight-600 mb-0">-->
                      <!--            Online shopping ..-->
                      <!--          </p>-->
                      <!--          <p class="fs-13 text-muted mb-0">-->
                      <!--            <span class="mr-2">Photo </span>10-->
                      <!--            Minutes ago-->
                      <!--          </p>-->
                      <!--          <p class="mb-0 fs-13">-->
                      <!--            Lorem Ipsum has been-->
                      <!--          </p>-->
                      <!--        </div>-->
                      <!--      </div>-->
                      <!--    </div>-->
                      <!--  </div>-->
                      <!--</div>-->
                      <!--<div class="row">-->
                      <!--  <div class="col-sm-12">-->
                      <!--    <div class="pt-3">-->
                      <!--      <div class="row">-->
                      <!--        <div class="col-sm-5 pr-2">-->
                      <!--          <div class="rotate-img">-->
                      <!--            <img-->
                      <!--              src="/site/assets/images/dashboard/home_22.jpg"-->
                      <!--              alt="thumb"-->
                      <!--              class="img-fluid w-100"-->
                      <!--            />-->
                      <!--          </div>-->
                      <!--        </div>-->
                      <!--        <div class="col-sm-7 pl-2">-->
                      <!--          <p class="fs-16 font-weight-600 mb-0">-->
                      <!--            Online shopping ..-->
                      <!--          </p>-->
                      <!--          <p class="fs-13 text-muted mb-0">-->
                      <!--            <span class="mr-2">Photo </span>10-->
                      <!--            Minutes ago-->
                      <!--          </p>-->
                      <!--          <p class="mb-0 fs-13">-->
                      <!--            Lorem Ipsum has been-->
                      <!--          </p>-->
                      <!--        </div>-->
                      <!--      </div>-->
                      <!--    </div>-->
                      <!--  </div>-->
                      <!--</div>-->
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  <script>
      
      $(document).ready(function(){
       $(document).on('click','.pagination a', function(event){
           
           event.preventDefault();
           var page = $(this).attr('href').split('page=')[1];
           getmorepol(page);
       });
          
      });
      
      
      function getmorepol(page){
          $.ajax({
              type: "GET",
              url: "{{route('get-more-pol')}}",
              success: function(data){
               $('#pol_data'). html(data); 
                  
              }
          })
      }
  </script>

@endsection