

<?php $__env->startSection('content'); ?>




    <div class="content-wrapper">
      <div class="card">
<div class="card-body">
<h4 class="card-title">All Politics Post</h4>
<div class="row">
  <div class="col-12">
    <div class="table-responsive">
        <table id="order-listing" class="table">
          <?php if(count($politics)>0): ?>
          <thead>
            <tr>
              <th>s/n</th>
              <th>title </th>
              
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $politics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $politics): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td>i++</td>
              <td><?php echo e($politics->title); ?></td>
              

              <td>
                <a href=""> <i class="fa fa-edit text-blue">Edit</i></a> /
                <a href=""> <i class="fa fa-trash "></i>Delete</a>
              </td>
              <td>
                
               
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
          </tbody>
          <?php else: ?>
          <p>You Have no post</p>
          
          <?php endif; ?>
        </table>
         
        
      </div>
    </div>
</div>
</div>

    </div>
    
   
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\KogiNewsBlog\resources\views/politicsview.blade.php ENDPATH**/ ?>